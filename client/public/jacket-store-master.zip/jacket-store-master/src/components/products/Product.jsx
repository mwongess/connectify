const Product = () => {
  return (
    <div>
      <img
        className="h-[10rem]"
        src="https://cactusoutdoor.co.nz/cdn/shop/files/CACTUS_DOWNJACKET_mens_grnHERO_fa9c2f6c-5d6d-4b1f-8f72-d0d428ea063a_1200x630.png?v=1686518746"
        alt=""
      />
      <p>Mens Winter Jacket</p>

      <p>$99</p>
    </div>
  );
};

export default Product;
