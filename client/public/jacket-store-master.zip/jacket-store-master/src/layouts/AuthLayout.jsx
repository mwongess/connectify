const AuthLayout = () => {
  return (
    <div>AuthLayout</div>
  )
}

export default AuthLayout