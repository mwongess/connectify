/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.jsx", "./src/**/**/*.js", "./src/*.js"],
  theme: {
    extend: {},
  },
  plugins: [],
};
